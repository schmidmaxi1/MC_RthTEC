/*
 * myTimers.c
 *
 * Created: 20.03.2019 12:47:49
 *  Author: schmidm
 */ 

/*
 ** Includes
 */

#include "Config.h" //Doppelpunkte um einen Ordner zur�ck zu gehen
#include "helper.h"
#include "globalVAR.h"

#include "my_PulseSequence.h"

//#include "main.h"
#include "my_Timers.h"
#include "avr/common.h"

#include <util/delay.h>
#include "avr/interrupt.h"

#include "Cards/All_Cards.h"

/*
 ** Local Variables
 */

volatile uint8_t interrupt_1ms;
volatile uint8_t interrupt_10hz;
volatile uint8_t interrupt_1hz;

uint8_t heat_pulse_precount;
uint16_t heat_pulse_lastcount;
uint8_t measure_pulse_precount;
uint16_t measure_pulse_lastcount;

uint16_t deterministic_pulse_counter;

//Flags
uint8_t flag_std_TTA;
uint8_t flag_DPA_TTA;
uint8_t flag_HPP_TTA;


/*
 ** Functions
 */

//This line is used to suppress the warnings for code Folding
// It is ignored by the compiler
//At the end of the Code it must be closed
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunknown-pragmas"


//////////////////////////////////////////////////////////////////////////////////
//							TIMER 2  ---  1ms Clock					   		    //
//////////////////////////////////////////////////////////////////////////////////

#pragma region Timer2

/* Explanation:
	-Timer executes an Interrupt every 1ms
	-An Internal Counter is incremented [interrupt_1ms]
	-This Counter is compared in the main loop to set:
		*LED Status
		*Dividing for other Counters
*/

//Initialization
void Init_Timer_1ms()
{
	//Timer 2 -> common interrupt, 1ms***************************************
	/* Explanation: (Data sheet from page 169)
		1ms Interrupt used in main loop (z.B. Signal LEDs)
	 	
		-Used as 8 bit Timer
		-WGM   2:0 = 7 --> FastPWM mode; OCR2A = top
		-COM2A 1:0 = 0 --> Normal operation, OC2A disconnected
		-COM2B 1:0 = 0 --> Normal operation, OC2B disconnected
		-FOC2A 0:0 = 0 --> Muss 0 im PWM Mode
		-FOC2B 0:0 = 0 --> Muss 0 im PWM Mode
		-CS2   2:0 = 4 --> Prescaler 64 ( ->4�s steps)
	 
		-ORC2A = 249 ( 250 * 4�s = 1ms (Overflow jede ms))
	 
		-OCIE2A = 1 (If ORCA2 is reached, Interrupt and set to 0 [every 1ms])
		*/	
		
	TCCR2A = _BV(WGM21) | _BV(WGM20);
	TCCR2B = _BV(CS22)  | _BV(WGM22);
	OCR2A = 249;							//Compare at 249 => 1msec
	TIMSK2 = _BV(OCIE2A);					//Compare interrupt enable
	
	/*Optional: Output Pin
		TCCR2A = _BV(COM2B1); //Clear on match
		OCR2B = 1; //Compare at 1 => 4usec pulse
		_set_out(PORTH,6); //CLK for T4 (T5)
	*/
}

//Interrupt
ISR(TIMER2_COMPA_vect)
{
	//Increment internal Counter
	interrupt_1ms++;
}

#pragma endregion Timer2

//////////////////////////////////////////////////////////////////////////////////
//							TIMER 1  ---  100us Clock							//
//////////////////////////////////////////////////////////////////////////////////

#pragma region Timer1

/* Explanation:
	-Timer drives an Output Pin with an PWM
	-100�s period with 1�s on
	-The Pin is routed to the Input of Timer 5 (used as Counter)
	-The Timer is started when an Pulse should be driven
	-And stop afterwards
*/

//Initialization
void Init_Timer_100us()
{
	//Timer 1 -> Puls generator prescaler, 1ms********************************
	/* Explanation: (Data sheet from page 133)
		Generates an PWM Signal with 100�s period an 1�s on
		Pin B5 (ORCA1) is routed to Input to Timer 5
	 	
	  -Used as 16 bit Timer
	  -WGM   3:0 = 14 --> FastPWM mode; ICR1 = top
	  -COM1A 1:0 = 2 --> OC1A (Pin) on match & set at 0
	  -COM1B 1:0 = 0 --> Normal operation, OC4A disconnected
	  -COM1C 1:0 = 0 --> Normal operation, OC4A disconnected
	  -ICNC1 0:0 = 0 --> Kein Eingangs-Noise Filter (nur bei Counter)
	  -ICES1 0:0 = 0 --> Flanken auswahl (nur bei Counter)
	  -CS2   2:0 = 0 --> Prescaler nicht definiert (Sp�ter 1). Clock l�uft nicht!
	 
	  -ICR4 = 1599  --> Bei 16MHz entspricht �berlauf nach 100�s
	  -OCR4C = 16    --> Bei Match wird Pin H4 gecleart (nach 1�s)
	 */		
	TCCR1B = _BV(WGM13) | _BV(WGM12); 
	TCCR1A = _BV(COM1A1) | _BV(WGM11);  // | _BV(COM4B1); //COM4B1 kann weggelassen werden
	ICR1 = 1599;
	OCR1A = 16; //Compare at 1 => 1usec pulse
	OCR1B = -1; //Unused
	OCR1C = -1; //Unused
	
	//Counter Pin as Output
	set_out(CounterPin);
	
}

//Start Clock
void Start_Timer_100us(){
    //Starts when a pre scaler is set to an Value (One is chosen)
    _set_bit(TCCR1B, CS10);                     //Timer 1 run
}

//Stop Clock
void Stop_Timer_100us()
{
	//Remove prescalar to stop the Timer
	_clear_bit(TCCR1B, CS10);                   //Timer 1 stop
	//Clear counter register to 0xFFFF
	TCNT1 = -1;
}

#pragma endregion Timer1

//////////////////////////////////////////////////////////////////////////////////
//							TIMER 5  ---  100us Counter							//
//////////////////////////////////////////////////////////////////////////////////

#pragma region Timer5

/* Explanation:
	-Timer acts as counter
	-Input is a 100�s generated by Timer1
	-HP and MP Pins are switched by the interrupts of compare registers
	-If time exceeds 6000ms (BitLimit at 645536) a pre-counter is used
	-
*/

//Initialization
void Init_Counter_100us()
{
	//Timer 5 -> Puls generator***********************************************
	/* Erkl�rung: (Datenblatt ab Seite 133)
		Timer f�r die generierung von Heiz- und Messpulsen
		1ms Eingangs Frequenz
		Geschalten wird �ber die Compare Interrupts A, B und C
	 	
	  -Genutzt als 16 bit Counter
	  -WGM   3:0 = 14 --> FastPWM mode; ICR5 = top
	  -COM4A 1:0 = 0 --> Normal operation, OC5A disconnected
	  -COM4B 1:0 = 0 --> Normal operation, OC5B disconnected
	  -COM4C 1:0 = 0 --> Normal operation, OC5C disconnected
	  -ICNC4 0:0 = 0 --> Kein Eingangs-Noise Filter (nur bei Counter)
	  -ICES4 0:0 = 0 --> Flanken auswahl (nur bei Counter)
	  -CS2   2:0 = 7 --> External clock source on Tn pin. Clock on rising edge
	  -OCIE5A    = 1 --> Interrupt Enable [B und C auch]

	 
	  -ICR5 = 60000  --> �berlauf nach 1 Minute
	  -OCR5A = 1    --> Bei Match wird Pin H4 gecleart (nach 1ms)[Genau so B und C]
						Der Wert wird nachher ge�ndert
	 */		
	TCCR5B = _BV(WGM53) | _BV(WGM52) | _BV(CS52) | _BV(CS51) | _BV(CS50); //Fast PWM mode, ICR5 -> top, clock T5
	ICR5 = 60000; //60000;
	TCCR5A = _BV(WGM51); //Clear on match
	TIMSK5 = _BV(OCIE5B) | _BV(OCIE5A) | _BV(OCIE5C) | _BV(TOIE5); //Compare interrupt enable + Overflow Interrupt
	OCR5A = 1; //Compare at 1 => 1msec pulse
	OCR5B = 1; //Compare at 1 => 1msec pulse
	OCR5C = 1; //Compare at 1 => 1msec pulse
}

//Setup for std. TTA
void Setup_Counter_for_stdTTA()
{
	//Reset overflow and Counter
	TCNT5 = 59999;      //Timer 5 reset
	ICR5 = 60000;		//6000ms = 6s
	
	// *10 wegen umstieg von 1ms auf 100�s
	if (heat_pulse_length < 6000)
	{
		OCR5A = heat_pulse_length * 10;
		heat_pulse_lastcount = heat_pulse_length * 10;
		heat_pulse_precount = 0;
			
		//Spannungsmessung 5ms vor Puls-Ende
		OCR5C = (heat_pulse_length - 5)* 10;
	}
	else
	{
		OCR5A = -1;
		heat_pulse_lastcount = (heat_pulse_length % 6000) * 10;
		heat_pulse_precount = (heat_pulse_length) / 6000; //Aufrunden
			
	}
		
	if (measure_pulse_length < 6000)
	{
		OCR5B = (measure_pulse_length) * 10;
		measure_pulse_lastcount = measure_pulse_length * 10;
		measure_pulse_precount = 0;
	}
	else
	{
		OCR5B = -1;
		measure_pulse_lastcount = (measure_pulse_length % 6000) * 10;
		measure_pulse_precount = (measure_pulse_length) / 6000;
	}	
}

//Setup for det. TTA
void Setup_Counter_for_DPA_TTA()
{	
	/*
	Explanation:
	-HP on at Overflow
	-HP off at OCR5A
	-MP always on
	*/
	ICR5 = 2 * deterministic_pulse_length - 1;		//Overflow at periode: 2*length - 1bit (start @ 0 not 1)
	TCNT5 = 2 * deterministic_pulse_length - 2;		//Counter starting on Clock before (Interrupts not active first time)
	//Interrupts
	OCR5A = deterministic_pulse_length - 1;			//Switch off HP at length - 1bit (start @ 0 not 1)
	OCR5B = -1;		//Not used
	OCR5C = -1;		//Not used
	
	//Replace Counter
	deterministic_pulse_counter =deterministic_pulse_cycles;
}

void Setup_Counter_for_DPA_TTA_HighLevel()
{
	//Reset overflow and Counter
	TCNT5 = 59999;      //Timer 5 reset
	ICR5 = 60000;		//6000ms = 6s
		
	// *10 wegen umstieg von 1ms auf 100�s
	if (heat_pulse_length < 6000)
	{
		OCR5A = heat_pulse_length * 10;
		heat_pulse_lastcount = heat_pulse_length * 10;
		heat_pulse_precount = 0;
			
		//Spannungsmessung 5ms vor Puls-Ende
		//OCR5C = (heat_pulse_length - 5)* 10;
	}
	else
	{
		OCR5A = -1;
		heat_pulse_lastcount = (heat_pulse_length % 6000) * 10;
		heat_pulse_precount = (heat_pulse_length) / 6000; //Aufrunden			
	}
	//Comp B is not needed
	OCR5B = -1;	
}


//Interrupt: OverFlow:
ISR(TIMER5_OVF_vect)
{	
	//If Deterministic Pulses are running (switch on HP)
	if(flag_DPA_TTA)
	{			
		//--> Wieder anschalten
		HP_Port = pulse_output_register;
		MP_Port = pulse_output_register;
		
		if(deterministic_pulse_counter-- <= 0)
		{
			//Stop Timer
			Stop_Timer_100us();
									
			//Start standard TTA
			PulseStart_stdTTA();
		}
	}
	//If standard TTA (change compare register for overflow)	
	else if(flag_std_TTA)
	{
		if (--heat_pulse_precount <= 0)
		{
			OCR5A = heat_pulse_lastcount;
		}

		if (--measure_pulse_precount <= 0)
		{
			OCR5B = measure_pulse_lastcount;
		}
	}
	else if (flag_HPP_TTA)
	{
		if (--heat_pulse_precount <= 0)
		{
			OCR5A = heat_pulse_lastcount;
		}		
	}
	//Should not be possible
	else
	{
	}
	
		
}

//Interrupt: Compare A: Switch of Heat pulse
ISR(TIMER5_COMPA_vect)
{
	//Wenn es ein Heat PrePulse ist, in DPA gehn
	if(flag_HPP_TTA)
	{
		PulseStart_DPA_TTA_fromHPP();
	}
	else
	{
		HP_Port = 0;	
	}
	
	//OLD***********************
	//Switch of all Heat Pulses
	//HP_Port = 0;	
}

//Interrupt: Compare B: Switch of Meas pulse
ISR(TIMER5_COMPB_vect)
{
	//Interrupt f�r Tx und Rx zulassen (Alle Interrupts zulassen)
	//Flag wurde vohrer auf falsch gesetzt
	SREG |= _BV(SREG_I); 

	//Timer 4  stopen-> Prescaler
	Stop_Timer_100us();
	
	//Execute Heat-Measurements for all active slots which need it
	for(int i = 0; i < 8; i++)
	{
		//Only execute if slot is active
		if(pulse_output_register & 0x1 << i)
		{
			//Only execute for a few card types
			//MOSFET
			if(card_Type[i] == 'M')
			{
				measured_binary_heat[i] = MOSFET_Source_sample_Meas_receive_Heat(i+1);
				measured_binary_meas[i] = MOSFET_Source_receive_Meas(i+1);
			}
			else if(card_Type[i] == 'F')
			{
				//Not realized yet
			}
				
		}
	}
	
/*	OLD
	//Daten der Heat-Puls Spannungsmessung abholen
	heat_pulse_voltage = Measure_Voltage_MOSFET_get_Data();
	//Spannung f�r Mess-Pulse messen
	measure_pulse_voltage = Measure_Voltage_MOSFET_with_DataAnalyse();
*/
	
	//Switch of STD_TTA
	MP_Port = 0;
		
	//clear Compare Registera
	OCR5B = -1;
						
	//Status LED for Pulses
	clear_bit(LED_Pulse);
}

//Interrupt: Compare C: Voltage_Measurement ADC
ISR(TIMER5_COMPC_vect)
{
	//Interrupt f�r Tx und Rx zulassen (Alle Interrupts zulassen)
	//Flag wurde vohrer auf falsch gesetzt
	SREG |= _BV(SREG_I); 
	
	//Execute Heat-Measurements for all active slots which need it
	for(volatile int i = 0; i < 8; i++)
	{
		//Only execute if slot is active
		if(pulse_output_register & 0x1 << i)
		{
			//Only execute for a few card types
			//MOSFET
			if(card_Type[i] == 'M')
			{
				MOSFET_Source_sample_Heat(i+1);
			}
			else if(card_Type[i] == 'F')
			{
				//Not realized yet
			}
		
		}		
	}
	
	//OLD
	//Measure_Voltage_MOSFET_without_DataAnalyse();	
}

#pragma endregion Timer5



#pragma GCC diagnostic pop